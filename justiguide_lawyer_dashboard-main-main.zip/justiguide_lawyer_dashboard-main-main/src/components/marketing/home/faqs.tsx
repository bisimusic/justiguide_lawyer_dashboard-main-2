'use client';

import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Chip from '@mui/material/Chip';
import Collapse from '@mui/material/Collapse';
import Container from '@mui/material/Container';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { CaretDown as CaretDownIcon } from '@phosphor-icons/react/dist/ssr/CaretDown';
import { CaretRight as CaretRightIcon } from '@phosphor-icons/react/dist/ssr/CaretRight';
import { Question as QuestionIcon } from '@phosphor-icons/react/dist/ssr/Question';

const faqs = [
  {
    id: 'JustiGuide-FAQ-1',
    question: 'Does JustiGuide offer a trial to explore the platform before subscription?',
    answer:
      'Absolutely! JustiGuide provides a demo version so you can experience the user-friendly interface and innovative features firsthand. Note that the full suite of tools available in the subscribed version may not be present in the demo.',
  },
  {
    id: 'JustiGuide-FAQ-2',
    question: 'Can JustiGuide be used for multiple asylum cases?',
    answer:
      'Yes, once you subscribe to JustiGuide, you can manage multiple cases simultaneously. Our platform is designed to scale with your needs, whether youre handling a single case or coordinating numerous asylum applications.',
  },
  {
    id: 'JustiGuide-FAQ-3',
    question: 'Is JustiGuide suitable for all kinds of legal professionals?',
    answer:
      'Indeed, JustiGuide is tailored for attorneys specializing in immigration and asylum law. Our tools are also beneficial for legal aid organizations and pro bono professionals seeking efficient case management solutions.',
  },
  {
    id: 'JustiGuide-FAQ-4',
    question: 'What devices and browsers are compatible with JustiGuide?',
    answer:
      'JustiGuide is accessible on any modern device with internet connectivity, including tablets and smartphones. It supports the latest versions of all major browsers such as Chrome, Firefox, Safari, and Edge. We ensure compatibility with up-to-date technology to provide the best user experience.',
  },
  {
    id: 'JustiGuide-FAQ-5',
    question: 'Who can benefit from the Standard license of JustiGuide?',
    answer:
      'The Standard license is ideal for small to mid-size legal firms and individual practitioners. It allows internal use for teams to collaborate on case management and document preparation for their asylum-seeking clients.',
  },
] satisfies { id: string; question: string; answer: string }[];

export function Faqs(): React.JSX.Element {
  return (
    <Box sx={{ bgcolor: 'var(--mui-palette-background-level1)', py: '120px' }}>
      <Container maxWidth="md">
        <Stack spacing={8}>
          <Stack maxWidth="700px" sx={{ mx: 'auto' }}>
            <Stack spacing={2}>
              <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                <Chip color="primary" icon={<QuestionIcon />} label="FAQ" variant="soft" />
              </Box>
              <Typography sx={{ textAlign: 'center' }} variant="h3">
                Questions we get asked
              </Typography>
              <Typography color="text.secondary">
                Have another question you do not see here? Contact us by{' '}
                <Box
                  component="a"
                  href="mailto:support@deviasio.zendesk.com"
                  sx={{ color: 'inherit', textDecoration: 'underline' }}
                >
                  email
                </Box>
                .
              </Typography>
            </Stack>
          </Stack>
          <Stack spacing={2}>
            {faqs.map((faq) => (
              <Faq key={faq.id} {...faq} />
            ))}
          </Stack>
        </Stack>
      </Container>
    </Box>
  );
}

export interface FaqProps {
  answer: string;
  question: string;
}

function Faq({ answer, question }: FaqProps): React.JSX.Element {
  const [isExpanded, setIsExpanded] = React.useState<boolean>(false);

  return (
    <Card sx={{ p: 3 }}>
      <Stack
        onClick={() => {
          setIsExpanded((prevState) => !prevState);
        }}
        sx={{ cursor: 'pointer' }}
      >
        <Stack direction="row" spacing={2} sx={{ alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant="subtitle1">{question}</Typography>
          {isExpanded ? <CaretDownIcon /> : <CaretRightIcon />}
        </Stack>
        <Collapse in={isExpanded}>
          <Typography color="text.secondary" sx={{ pt: 3 }} variant="body2">
            {answer}
          </Typography>
        </Collapse>
      </Stack>
    </Card>
  );
}

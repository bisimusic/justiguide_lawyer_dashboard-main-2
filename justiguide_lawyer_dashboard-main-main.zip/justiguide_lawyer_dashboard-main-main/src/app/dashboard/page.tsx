import * as React from 'react';
import type { Metadata } from 'next';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import { ArrowRight as ArrowRightIcon } from '@phosphor-icons/react/dist/ssr/ArrowRight';
import { Briefcase as BriefcaseIcon } from '@phosphor-icons/react/dist/ssr/Briefcase';
import { FileCode as FileCodeIcon } from '@phosphor-icons/react/dist/ssr/FileCode';
import { Info as InfoIcon } from '@phosphor-icons/react/dist/ssr/Info';
import { ListChecks as ListChecksIcon } from '@phosphor-icons/react/dist/ssr/ListChecks';
import { Plus as PlusIcon } from '@phosphor-icons/react/dist/ssr/Plus';
import { Users as UsersIcon } from '@phosphor-icons/react/dist/ssr/Users';
import { Warning as WarningIcon } from '@phosphor-icons/react/dist/ssr/Warning';

import { config } from '@/config';
import { dayjs } from '@/lib/dayjs';
import { AppChat } from '@/components/dashboard/overview/app-chat';
import { AppLimits } from '@/components/dashboard/overview/app-limits';
import { AppUsage } from '@/components/dashboard/overview/app-usage';
import { Events } from '@/components/dashboard/overview/events';
import { HelperWidget } from '@/components/dashboard/overview/helper-widget';
import { Subscriptions } from '@/components/dashboard/overview/subscriptions';
import { Summary } from '@/components/dashboard/overview/summary';

export const metadata = { title: `Overview | Dashboard | ${config.site.name}` } satisfies Metadata;

export default function Page(): React.JSX.Element {
  return (
    <Box
      sx={{
        maxWidth: 'var(--Content-maxWidth)',
        m: 'var(--Content-margin)',
        p: 'var(--Content-padding)',
        width: 'var(--Content-width)',
      }}
    >
      <Stack spacing={4}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={3} sx={{ alignItems: 'flex-start' }}>
          <Box sx={{ flex: '1 1 auto' }}>
            <Typography variant="h4">Overview</Typography>
          </Box>
          <div>
            <Button startIcon={<PlusIcon />} variant="contained">
              Dashboard
            </Button>
          </div>
        </Stack>
        <Grid container spacing={4}>
          <Grid md={4} xs={12}>
            <Summary amount={31} diff={15} icon={ListChecksIcon} title="Tickets" trend="up" />
          </Grid>
          <Grid md={4} xs={12}>
            <Summary amount={240} diff={5} icon={UsersIcon} title="Sign ups" trend="down" />
          </Grid>
          <Grid md={4} xs={12}>
            <Summary amount={21} diff={12} icon={WarningIcon} title="Open issues" trend="up" />
          </Grid>
          <Grid md={8} xs={12}>
            <AppUsage
              data={[
                { name: 'Jan', v1: 36, v2: 19 },
                { name: 'Feb', v1: 45, v2: 23 },
                { name: 'Mar', v1: 26, v2: 12 },
                { name: 'Apr', v1: 39, v2: 20 },
                { name: 'May', v1: 26, v2: 12 },
                { name: 'Jun', v1: 42, v2: 31 },
                { name: 'Jul', v1: 38, v2: 19 },
                { name: 'Aug', v1: 39, v2: 20 },
                { name: 'Sep', v1: 37, v2: 18 },
                { name: 'Oct', v1: 41, v2: 22 },
                { name: 'Nov', v1: 45, v2: 24 },
                { name: 'Dec', v1: 23, v2: 17 },
              ]}
            />
          </Grid>
          <Grid md={4} xs={12}>
            <Subscriptions
              subscriptions={[
                {
                  id: 'justiguide_core',
                  title: 'JustiGuide Core',
                  icon: '/assets/justiguide-core.png',
                  costs: '$399',
                  billingCycle: 'month',
                  status: 'paid',
                },
                {
                  id: 'justiguide_legal_aid',
                  title: 'JustiGuide Legal Aid',
                  icon: '/assets/justiguide-legal-aid.png',
                  costs: '$499',
                  billingCycle: 'month',
                  status: 'paid',
                },
                {
                  id: 'justiguide_enterprise',
                  title: 'JustiGuide Enterprise',
                  icon: '/assets/justiguide-enterprise.png',
                  costs: 'Custom',
                  billingCycle: 'month',
                  status: 'paid',
                },
                {
                  id: 'docu_sign_integration',
                  title: 'DocuSign Integration',
                  icon: '/assets/docu-sign.png',
                  costs: 'Included with subscription',
                  billingCycle: 'month',
                  status: 'paid',
                },
                {
                  id: 'ai_multilingual_support',
                  title: 'AI Multilingual Support',
                  icon: '/assets/ai-multilingual.png',
                  costs: 'Included with subscription',
                  billingCycle: 'month',
                  status: 'paid',
                },
              ]}
            />
          </Grid>
          <Grid md={4} xs={12}>
            <AppChat
              messages={[
                {
                  id: 'MSG-001',
                  content:  'Hello, I read through the resources Dolores provided about the asylum process.',
                  author: { name: 'Amina Khalid', avatar: '/assets/avatar-10.png', status: 'online' },
                  createdAt: dayjs().subtract(2, 'minute').toDate(),
                },
                {
                  id: 'MSG-002',
                  content: 'Can you help me understand how long the document translation will take?',
                  author: { name: 'Carlos Mendoza', avatar: '/assets/avatar-9.png', status: 'offline' },
                  createdAt: dayjs().subtract(56, 'minute').toDate(),
                },
                {
                  id: 'MSG-003',
                  content: "I've filled out the form with the guidance from Dolores. Is everything in order?",
                  author: { name: 'Fatima Al-Farsi', avatar: '/assets/avatar-3.png', status: 'online' },
                  createdAt: dayjs().subtract(3, 'hour').subtract(23, 'minute').toDate(),
                },
                {
                  id: 'MSG-004',
                  content: 'Your case file looks complete. I will start the submission process shortly.',
                  author: { name: 'Fran Perez', avatar: '/assets/avatar-5.png', status: 'online' },
                  createdAt: dayjs().subtract(8, 'hour').subtract(6, 'minute').toDate(),
                },
                {
                  id: 'MSG-005',
                  content: 'Dolores mentioned some additional documents I might need. Could you confirm?',
                  author: { name: 'Jie Yan', avatar: '/assets/avatar-8.png', status: 'offline' },
                  createdAt: dayjs().subtract(10, 'hour').subtract(18, 'minute').toDate(),
                },
              ]}
            />
          </Grid>
          <Grid md={4} xs={12}>
            <Events
              events={[
                {
                  id: 'EV-004',
                  title: 'Meeting with partners',
                  description: '17:00 to 18:00',
                  createdAt: dayjs().add(1, 'day').toDate(),
                },
                {
                  id: 'EV-003',
                  title: 'Interview with Jonas',
                  description: '15:30 to 16:45',
                  createdAt: dayjs().add(4, 'day').toDate(),
                },
                {
                  id: 'EV-002',
                  title: "Biometric appointment",
                  description: '12:30 to 15:30',
                  createdAt: dayjs().add(4, 'day').toDate(),
                },
                {
                  id: 'EV-001',
                  title: 'Weekly meeting',
                  description: '09:00 to 09:30',
                  createdAt: dayjs().add(7, 'day').toDate(),
                },
              ]}
            />
          </Grid>
          <Grid md={4} xs={12}>
            <AppLimits usage={80} />
          </Grid>
          <Grid md={4} xs={12}>
            <HelperWidget
              action={
                <Button color="secondary" endIcon={<ArrowRightIcon />} size="small">
                  Search jobs
                </Button>
              }
              description="Search for clients that match your experience and review their applications directly."
              icon={BriefcaseIcon}
              label="Discover"
              title="Open Doors"
            />
          </Grid>
          <Grid md={4} xs={12}>
            <HelperWidget
              action={
                <Button color="secondary" endIcon={<ArrowRightIcon />} size="small">
                  Help center
                </Button>
              }
              description="Find answers to your questions and get in touch with our team."
              icon={InfoIcon}
              label="Help center"
              title="Need help figuring things out?"
            />
          </Grid>
          <Grid md={4} xs={12}>
            <HelperWidget
              action={
                <Button color="secondary" endIcon={<ArrowRightIcon />} size="small">
                  Documentation
                </Button>
              }
              description="Learn how to get started with our product and make the most of it."
              icon={FileCodeIcon}
              label="Documentation"
              title="Explore documentation"
            />
          </Grid>
        </Grid>
      </Stack>
    </Box>
  );
}
